
package com.example.SocialMedia;
import java.util.*;

public interface PostList {

    void setPost(Post post);
    List<Post> getAllPost();
}