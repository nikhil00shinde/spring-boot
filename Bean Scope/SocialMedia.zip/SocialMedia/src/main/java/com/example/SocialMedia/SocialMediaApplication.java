package com.example.SocialMedia;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class SocialMediaApplication {

	public static void main(String[] args) {
		// SpringApplication.run(SocialMediaApplication.class, args);
		System.out.println("Social Media Application Started");
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("ApplicationContext.xml");

		User user = (User) applicationContext.getBean("user");
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter User Name: ");
		String name = scanner.nextLine();
		user.setUserName(name);
		System.out.println("User Name Set to: " + user.getUserName());

		PostList postList = (PostList) applicationContext.getBean("postlist");
		user.setPostList(postList);

		while(true){ 
			System.out.println("Options: \n1. Add Post \n2. View All Posts");
			int option = scanner.nextInt();
			switch(option){
				case 1:
					Post post = (Post) applicationContext.getBean("post");
					System.out.println("Enter Post Content: ");
					scanner.nextLine();
					String content = scanner.nextLine();
					post.setMessage(content);
					postList.setPost(post);
					break;
				case 2:
					PostList temp = user.getPostList();
					temp.getAllPost().forEach(postt -> System.out.println(postt.getMessage()));
					break;
				default:
					break;
			}
		}
		// applicationContext.close();
		// scanner.close();
	}

}
