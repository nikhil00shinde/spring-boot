
package com.example.SocialMedia;

public interface Post {
    void setMessage(String message);  
    String getMessage();
    void setContent(String content);
}