package com.example.FirstSpring;

public interface Car {
    void showSpeed();
}
