package com.example.FirstSpring;

public class Family implements Car {
    @Override
    public void showSpeed() {
        System.out.println("Family car speed is 150 km/h");
    }

}
