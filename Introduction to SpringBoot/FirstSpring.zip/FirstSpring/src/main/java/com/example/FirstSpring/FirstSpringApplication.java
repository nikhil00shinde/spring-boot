package com.example.FirstSpring;

import java.util.Scanner;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class FirstSpringApplication {

	public static void main(String[] args) {

		// SpringApplication.run(FirstSpringApplication.class, args);
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("ApplicationContext.xml");

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter car type (sport, cyber, family):");
		String carType = scanner.nextLine().toLowerCase();

		switch (carType) {
			case "sport":
				Car sportCar = (Car)context.getBean("sport");
				sportCar.showSpeed();
				break;
			case "cyber":
				Car cyberCar = (Car)context.getBean("cyber");
				cyberCar.showSpeed();
				break;
			case "family":
				Car familyCar = (Car)context.getBean("family");
				familyCar.showSpeed();
				break;
			default:
				System.out.println("Unknown car type");
				break;
		}
		scanner.close();
		context.close();
	}
}