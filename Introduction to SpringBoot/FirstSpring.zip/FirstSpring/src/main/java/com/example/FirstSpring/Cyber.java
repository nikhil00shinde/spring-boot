package com.example.FirstSpring;

public class Cyber implements Car {
    @Override
    public void showSpeed() {
        System.out.println("Cyber car speed is 250 km/h");
    }
}
