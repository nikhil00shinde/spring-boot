package com.example.FirstSpring;

public class Sport implements Car {
    @Override
    public void showSpeed() {
        System.out.println("Sport car speed is 200 km/h");
    }
}
