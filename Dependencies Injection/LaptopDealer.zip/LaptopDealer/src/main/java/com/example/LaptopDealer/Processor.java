package com.example.LaptopDealer;

public interface Processor {

    String showProcessorDetails();
}