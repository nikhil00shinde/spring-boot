package com.example.LaptopDealer;

public class Macbook implements Brand{

    Processor processor;

    public Macbook(Processor processor){
        this.processor = processor;
    }

    @Override
    public void showDetails(){
        System.out.println("You have selected Macbook Laptop "+ processor.showProcessorDetails());
    }
}
