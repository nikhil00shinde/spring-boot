package com.example.LaptopDealer;

public interface Brand {

    void showDetails();
}