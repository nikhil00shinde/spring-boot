package com.example.LaptopDealer;

public class i3 implements Processor {
    
    @Override
    public String showProcessorDetails(){
        return "With i3 processor";
    }
}
