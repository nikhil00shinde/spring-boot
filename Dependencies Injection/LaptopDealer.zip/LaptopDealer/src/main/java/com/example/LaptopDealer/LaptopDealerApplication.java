package com.example.LaptopDealer;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class LaptopDealerApplication {

	public static void main(String[] args) {
		// SpringApplication.run(LaptopDealerApplication.class, args);
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("ApplicationContext.xml");

		Scanner scanner = new Scanner(System.in);
		System.out.println("Choose the brand you wanna buy: \n1. Dell \n2. Macbook  \n3. Microsoft");

		int userBrandSelect = scanner.nextInt();

		System.out.println("Choose the processor you want:\n1. i3 \n2. i5 \n3. i7");

		int userProcessorSelect = scanner.nextInt();

		String beanId = "";

		switch (userBrandSelect){
			case 1 -> {
				switch (userProcessorSelect) {
					case 1:
						beanId = "dellwithi3";
						break;
				
					case 2:
						beanId = "dellwithi5";
						break;
					
					case 3:
						beanId = "dellwithi7";
						break;
				}
				break;
			}
			case 2 -> {
					switch (userProcessorSelect) {
						case 1:
							beanId = "macboookwithi3";
							break;
					
						case 2:
							beanId = "macboookwithi5";
							break;
						
						case 3:
							beanId = "macboookwithi7";
							break;
					}
				break;
			}
			case 3 -> {
				switch (userProcessorSelect) {
						case 1:
							beanId = "microsoftwithi3";
							break;
					
						case 2:
							beanId = "microsoftwithi5";
							break;
						
						case 3:
							beanId = "microsoftwithi7";
							break;
					}
				break;
			}
		}

		Brand brand = (Brand) applicationContext.getBean(beanId);
		brand.showDetails();
		scanner.close();
		applicationContext.close();
	}

}
