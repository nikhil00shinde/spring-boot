package com.example.LaptopDealer;

public class Microsoft implements Brand {
    Processor processor;

    public void setProcessor(Processor processor ){
        this.processor = processor;
    }

    @Override
    public void showDetails(){
        System.out.println("You have selected Microsoft Laptop "+ processor.showProcessorDetails());
    }
}
