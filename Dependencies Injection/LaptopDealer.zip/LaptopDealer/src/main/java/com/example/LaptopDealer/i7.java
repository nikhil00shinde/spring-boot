package com.example.LaptopDealer;

public class i7 implements Processor {
    @Override
    public String showProcessorDetails(){
        return "With i7 processor";
    }
}
